﻿namespace Amigo_Chocolate.Dados.EntityFramework.Configurations
{
    public class DatabaseSettings
    {
        public string ConnectionString { get; set; }
    }
}
