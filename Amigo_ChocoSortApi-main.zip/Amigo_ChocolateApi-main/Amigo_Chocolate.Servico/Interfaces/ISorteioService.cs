﻿namespace Amigo_Chocolate.Servico.Interfaces
{
    public interface ISorteioService
    {
    }
}
