﻿namespace Amigo_Chocolate.Servico.Services
{
    public class RecuperaSenhaService
    {
    }
}
