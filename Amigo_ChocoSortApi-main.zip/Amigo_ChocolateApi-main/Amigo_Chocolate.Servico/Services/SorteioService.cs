﻿namespace Amigo_Chocolate.Servico.Services
{
    public class SorteioService
    {
    }
}
