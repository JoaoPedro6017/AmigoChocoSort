﻿namespace Amigo_Chocolate.Servico.ViewModels.Sorteio
{
    public class SorteioViewModel
    {
        public int Id_Sorteio { get; set; }
        public int Id_Usuario { get; set; }
        public int Id_Usuario_Sorteado { get; set; }
    }
}
