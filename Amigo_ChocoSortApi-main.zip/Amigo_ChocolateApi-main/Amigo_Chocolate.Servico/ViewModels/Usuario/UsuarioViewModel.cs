﻿namespace Amigo_Chocolate.Servico.ViewModels.Usuario
{
    public class UsuarioViewModel
    {
        public int IdUsuario { get; set; }
        public string? Foto { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
        public string Senha { get; set; }
        public int Id_Status { get; set; }
    }
}
