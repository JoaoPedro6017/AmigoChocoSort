﻿namespace Amigo_Chocolate.Servico.ViewModels.Login
{
    public class LoginViewModel
    {
        //public int IdLogin { get; set; }
        public string Email { get; set; }
        public string Senha { get; set; }
    }
}
