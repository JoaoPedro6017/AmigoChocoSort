﻿namespace Amigo_Chocolate.Servico.ViewModels.Login
{
    public class NovoLoginViewModel
    {
        public string Email { get; set; }
        public string Senha { get; set; }
    }
}
