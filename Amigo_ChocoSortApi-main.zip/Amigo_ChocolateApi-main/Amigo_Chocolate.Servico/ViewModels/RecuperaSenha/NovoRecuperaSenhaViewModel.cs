﻿namespace Amigo_Chocolate.Servico.ViewModels.RecuperaSenha
{
    public class NovoRecuperaSenhaViewModel
    {
        public int IdUsuario { get; set; }
        public DateTime DataSolicitacao { get; set; }
    }
}
