﻿namespace Amigo_Chocolate.Servico.ViewModels.RecuperaSenha
{
    public class RecuperaSenhaViewModel
    {
        //public int IdRecuperaSenha { get; set; }
        public int IdUsuario { get; set; }
        public DateTime DataSolicitacao { get; set; }
    }
}
