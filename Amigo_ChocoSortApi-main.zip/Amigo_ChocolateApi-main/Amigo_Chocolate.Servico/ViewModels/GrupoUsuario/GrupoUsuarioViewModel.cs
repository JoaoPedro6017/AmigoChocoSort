﻿namespace Amigo_Chocolate.Servico.ViewModels.GrupoUsuario
{
    public class GrupoUsuarioViewModel
    {
        public int IdGrupo { get; set; }
        public int IdUsuario { get; set; }
        public int Id_Status { get; set; }
    }
}
