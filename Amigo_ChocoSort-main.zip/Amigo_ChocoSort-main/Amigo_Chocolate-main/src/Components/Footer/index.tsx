import { StyledText1, StyledText2, StyledView } from "./styles";

export function Footer() {
    return (
        <StyledView>
            <StyledText1>2024 Copyright</StyledText1>
            <StyledText2>Joao Pedro Cruz - TI</StyledText2>
        </StyledView>
    )
}