export default {
    colors: {
        BACKGROUND_PRIMARY: '#000000',
        BACKGROUND_SECUNDARY: '#ffff',

        INFO: '#ecfc05',

        TEXT_PRIMARY: '#ffff',
        TEXT_SECUNDARY: '#000000',

        ICON: '#1D90F5'
    },
}